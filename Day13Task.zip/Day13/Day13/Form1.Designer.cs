﻿namespace Day13
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LblFullName = new System.Windows.Forms.Label();
            this.LblFirstName = new System.Windows.Forms.Label();
            this.LblLastName = new System.Windows.Forms.Label();
            this.LblPrefix = new System.Windows.Forms.Label();
            this.TxtFirstName = new System.Windows.Forms.TextBox();
            this.TxtlastName = new System.Windows.Forms.TextBox();
            this.ComboPrefix = new System.Windows.Forms.ComboBox();
            this.LblTitle = new System.Windows.Forms.Label();
            this.TxtTitle = new System.Windows.Forms.TextBox();
            this.LblCity = new System.Windows.Forms.Label();
            this.TxtCity = new System.Windows.Forms.TextBox();
            this.LblState = new System.Windows.Forms.Label();
            this.ComboState = new System.Windows.Forms.ComboBox();
            this.LblZipCode = new System.Windows.Forms.Label();
            this.TxtZipCode = new System.Windows.Forms.TextBox();
            this.LblHomePhone = new System.Windows.Forms.Label();
            this.LblMobilePhone = new System.Windows.Forms.Label();
            this.LblEmail = new System.Windows.Forms.Label();
            this.LblSkype = new System.Windows.Forms.Label();
            this.TxtHomePhone = new System.Windows.Forms.TextBox();
            this.TxtMobilePhone = new System.Windows.Forms.TextBox();
            this.TxtEmail = new System.Windows.Forms.TextBox();
            this.TxtSkype = new System.Windows.Forms.TextBox();
            this.LblDepartment = new System.Windows.Forms.Label();
            this.ComboDepartment = new System.Windows.Forms.ComboBox();
            this.LblStatus = new System.Windows.Forms.Label();
            this.ComboStatus = new System.Windows.Forms.ComboBox();
            this.LblHireDate = new System.Windows.Forms.Label();
            this.DtpHireDate = new System.Windows.Forms.DateTimePicker();
            this.LblDateofBirth = new System.Windows.Forms.Label();
            this.DtpDateofBirth = new System.Windows.Forms.DateTimePicker();
            this.BtnSubmit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Day13.Properties.Resources.picture;
            this.pictureBox1.Location = new System.Drawing.Point(26, 70);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(325, 359);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Employee";
            // 
            // LblFullName
            // 
            this.LblFullName.AutoSize = true;
            this.LblFullName.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFullName.Location = new System.Drawing.Point(188, 24);
            this.LblFullName.Name = "LblFullName";
            this.LblFullName.Size = new System.Drawing.Size(0, 31);
            this.LblFullName.TabIndex = 2;
            // 
            // LblFirstName
            // 
            this.LblFirstName.AutoSize = true;
            this.LblFirstName.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFirstName.Location = new System.Drawing.Point(357, 80);
            this.LblFirstName.Name = "LblFirstName";
            this.LblFirstName.Size = new System.Drawing.Size(103, 23);
            this.LblFirstName.TabIndex = 3;
            this.LblFirstName.Text = "First Name";
            // 
            // LblLastName
            // 
            this.LblLastName.AutoSize = true;
            this.LblLastName.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblLastName.Location = new System.Drawing.Point(357, 121);
            this.LblLastName.Name = "LblLastName";
            this.LblLastName.Size = new System.Drawing.Size(99, 23);
            this.LblLastName.TabIndex = 4;
            this.LblLastName.Text = "Last Name";
            // 
            // LblPrefix
            // 
            this.LblPrefix.AutoSize = true;
            this.LblPrefix.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPrefix.Location = new System.Drawing.Point(357, 160);
            this.LblPrefix.Name = "LblPrefix";
            this.LblPrefix.Size = new System.Drawing.Size(61, 23);
            this.LblPrefix.TabIndex = 5;
            this.LblPrefix.Text = "Prefix";
            // 
            // TxtFirstName
            // 
            this.TxtFirstName.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFirstName.Location = new System.Drawing.Point(489, 85);
            this.TxtFirstName.Name = "TxtFirstName";
            this.TxtFirstName.Size = new System.Drawing.Size(143, 32);
            this.TxtFirstName.TabIndex = 6;
            // 
            // TxtlastName
            // 
            this.TxtlastName.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtlastName.Location = new System.Drawing.Point(489, 121);
            this.TxtlastName.Name = "TxtlastName";
            this.TxtlastName.Size = new System.Drawing.Size(143, 32);
            this.TxtlastName.TabIndex = 7;
            // 
            // ComboPrefix
            // 
            this.ComboPrefix.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboPrefix.FormattingEnabled = true;
            this.ComboPrefix.Items.AddRange(new object[] {
            "Mr.",
            "Mrs"});
            this.ComboPrefix.Location = new System.Drawing.Point(489, 160);
            this.ComboPrefix.Name = "ComboPrefix";
            this.ComboPrefix.Size = new System.Drawing.Size(84, 31);
            this.ComboPrefix.TabIndex = 8;
            // 
            // LblTitle
            // 
            this.LblTitle.AutoSize = true;
            this.LblTitle.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTitle.Location = new System.Drawing.Point(357, 195);
            this.LblTitle.Name = "LblTitle";
            this.LblTitle.Size = new System.Drawing.Size(48, 23);
            this.LblTitle.TabIndex = 9;
            this.LblTitle.Text = "Title";
            // 
            // TxtTitle
            // 
            this.TxtTitle.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTitle.Location = new System.Drawing.Point(489, 200);
            this.TxtTitle.Name = "TxtTitle";
            this.TxtTitle.Size = new System.Drawing.Size(143, 32);
            this.TxtTitle.TabIndex = 10;
            // 
            // LblCity
            // 
            this.LblCity.AutoSize = true;
            this.LblCity.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCity.Location = new System.Drawing.Point(357, 236);
            this.LblCity.Name = "LblCity";
            this.LblCity.Size = new System.Drawing.Size(45, 23);
            this.LblCity.TabIndex = 11;
            this.LblCity.Text = "City";
            // 
            // TxtCity
            // 
            this.TxtCity.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCity.Location = new System.Drawing.Point(489, 236);
            this.TxtCity.Name = "TxtCity";
            this.TxtCity.Size = new System.Drawing.Size(143, 32);
            this.TxtCity.TabIndex = 12;
            // 
            // LblState
            // 
            this.LblState.AutoSize = true;
            this.LblState.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblState.Location = new System.Drawing.Point(357, 271);
            this.LblState.Name = "LblState";
            this.LblState.Size = new System.Drawing.Size(51, 23);
            this.LblState.TabIndex = 13;
            this.LblState.Text = "State";
            // 
            // ComboState
            // 
            this.ComboState.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboState.FormattingEnabled = true;
            this.ComboState.Items.AddRange(new object[] {
            "Odisha",
            "Mumbai",
            "Delhi",
            "Kolkat",
            "TamilNadu"});
            this.ComboState.Location = new System.Drawing.Point(489, 271);
            this.ComboState.Name = "ComboState";
            this.ComboState.Size = new System.Drawing.Size(102, 31);
            this.ComboState.TabIndex = 14;
            this.ComboState.Text = "--State--";
            // 
            // LblZipCode
            // 
            this.LblZipCode.AutoSize = true;
            this.LblZipCode.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblZipCode.Location = new System.Drawing.Point(357, 313);
            this.LblZipCode.Name = "LblZipCode";
            this.LblZipCode.Size = new System.Drawing.Size(82, 23);
            this.LblZipCode.TabIndex = 15;
            this.LblZipCode.Text = "ZipCode";
            // 
            // TxtZipCode
            // 
            this.TxtZipCode.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtZipCode.Location = new System.Drawing.Point(489, 318);
            this.TxtZipCode.Name = "TxtZipCode";
            this.TxtZipCode.Size = new System.Drawing.Size(143, 32);
            this.TxtZipCode.TabIndex = 16;
            // 
            // LblHomePhone
            // 
            this.LblHomePhone.AutoSize = true;
            this.LblHomePhone.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblHomePhone.Location = new System.Drawing.Point(732, 94);
            this.LblHomePhone.Name = "LblHomePhone";
            this.LblHomePhone.Size = new System.Drawing.Size(118, 23);
            this.LblHomePhone.TabIndex = 17;
            this.LblHomePhone.Text = "Home Phone";
            // 
            // LblMobilePhone
            // 
            this.LblMobilePhone.AutoSize = true;
            this.LblMobilePhone.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMobilePhone.Location = new System.Drawing.Point(731, 129);
            this.LblMobilePhone.Name = "LblMobilePhone";
            this.LblMobilePhone.Size = new System.Drawing.Size(127, 23);
            this.LblMobilePhone.TabIndex = 18;
            this.LblMobilePhone.Text = "Mobile Phone";
            // 
            // LblEmail
            // 
            this.LblEmail.AutoSize = true;
            this.LblEmail.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEmail.Location = new System.Drawing.Point(732, 163);
            this.LblEmail.Name = "LblEmail";
            this.LblEmail.Size = new System.Drawing.Size(60, 23);
            this.LblEmail.TabIndex = 19;
            this.LblEmail.Text = "Email";
            // 
            // LblSkype
            // 
            this.LblSkype.AutoSize = true;
            this.LblSkype.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSkype.Location = new System.Drawing.Point(731, 195);
            this.LblSkype.Name = "LblSkype";
            this.LblSkype.Size = new System.Drawing.Size(59, 23);
            this.LblSkype.TabIndex = 20;
            this.LblSkype.Text = "Skype";
            // 
            // TxtHomePhone
            // 
            this.TxtHomePhone.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtHomePhone.Location = new System.Drawing.Point(874, 85);
            this.TxtHomePhone.Name = "TxtHomePhone";
            this.TxtHomePhone.Size = new System.Drawing.Size(211, 32);
            this.TxtHomePhone.TabIndex = 21;
            // 
            // TxtMobilePhone
            // 
            this.TxtMobilePhone.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtMobilePhone.Location = new System.Drawing.Point(871, 120);
            this.TxtMobilePhone.Name = "TxtMobilePhone";
            this.TxtMobilePhone.Size = new System.Drawing.Size(214, 32);
            this.TxtMobilePhone.TabIndex = 22;
            // 
            // TxtEmail
            // 
            this.TxtEmail.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtEmail.Location = new System.Drawing.Point(871, 161);
            this.TxtEmail.Name = "TxtEmail";
            this.TxtEmail.Size = new System.Drawing.Size(214, 32);
            this.TxtEmail.TabIndex = 23;
            // 
            // TxtSkype
            // 
            this.TxtSkype.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtSkype.Location = new System.Drawing.Point(871, 201);
            this.TxtSkype.Name = "TxtSkype";
            this.TxtSkype.Size = new System.Drawing.Size(214, 32);
            this.TxtSkype.TabIndex = 24;
            // 
            // LblDepartment
            // 
            this.LblDepartment.AutoSize = true;
            this.LblDepartment.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDepartment.Location = new System.Drawing.Point(731, 236);
            this.LblDepartment.Name = "LblDepartment";
            this.LblDepartment.Size = new System.Drawing.Size(107, 23);
            this.LblDepartment.TabIndex = 25;
            this.LblDepartment.Text = "Department";
            // 
            // ComboDepartment
            // 
            this.ComboDepartment.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboDepartment.FormattingEnabled = true;
            this.ComboDepartment.Items.AddRange(new object[] {
            "It",
            "Sales",
            "Hr",
            "Customer Operation"});
            this.ComboDepartment.Location = new System.Drawing.Point(871, 240);
            this.ComboDepartment.Name = "ComboDepartment";
            this.ComboDepartment.Size = new System.Drawing.Size(128, 31);
            this.ComboDepartment.TabIndex = 26;
            // 
            // LblStatus
            // 
            this.LblStatus.AutoSize = true;
            this.LblStatus.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblStatus.Location = new System.Drawing.Point(731, 271);
            this.LblStatus.Name = "LblStatus";
            this.LblStatus.Size = new System.Drawing.Size(61, 23);
            this.LblStatus.TabIndex = 27;
            this.LblStatus.Text = "Status";
            // 
            // ComboStatus
            // 
            this.ComboStatus.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboStatus.FormattingEnabled = true;
            this.ComboStatus.Items.AddRange(new object[] {
            "Salaried",
            "UnSalaried"});
            this.ComboStatus.Location = new System.Drawing.Point(871, 275);
            this.ComboStatus.Name = "ComboStatus";
            this.ComboStatus.Size = new System.Drawing.Size(128, 31);
            this.ComboStatus.TabIndex = 28;
            // 
            // LblHireDate
            // 
            this.LblHireDate.AutoSize = true;
            this.LblHireDate.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblHireDate.Location = new System.Drawing.Point(731, 312);
            this.LblHireDate.Name = "LblHireDate";
            this.LblHireDate.Size = new System.Drawing.Size(91, 23);
            this.LblHireDate.TabIndex = 29;
            this.LblHireDate.Text = "Hire Date";
            // 
            // DtpHireDate
            // 
            this.DtpHireDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtpHireDate.CustomFormat = "dd/MM/yyyy";
            this.DtpHireDate.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtpHireDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DtpHireDate.Location = new System.Drawing.Point(874, 318);
            this.DtpHireDate.Name = "DtpHireDate";
            this.DtpHireDate.Size = new System.Drawing.Size(125, 32);
            this.DtpHireDate.TabIndex = 30;
            // 
            // LblDateofBirth
            // 
            this.LblDateofBirth.AutoSize = true;
            this.LblDateofBirth.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDateofBirth.Location = new System.Drawing.Point(731, 358);
            this.LblDateofBirth.Name = "LblDateofBirth";
            this.LblDateofBirth.Size = new System.Drawing.Size(120, 23);
            this.LblDateofBirth.TabIndex = 31;
            this.LblDateofBirth.Text = "Date of Birth";
            // 
            // DtpDateofBirth
            // 
            this.DtpDateofBirth.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtpDateofBirth.CustomFormat = "dd/MM/yyyy";
            this.DtpDateofBirth.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtpDateofBirth.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DtpDateofBirth.Location = new System.Drawing.Point(874, 361);
            this.DtpDateofBirth.Name = "DtpDateofBirth";
            this.DtpDateofBirth.Size = new System.Drawing.Size(125, 32);
            this.DtpDateofBirth.TabIndex = 32;
            // 
            // BtnSubmit
            // 
            this.BtnSubmit.AutoSize = true;
            this.BtnSubmit.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSubmit.Location = new System.Drawing.Point(642, 406);
            this.BtnSubmit.Name = "BtnSubmit";
            this.BtnSubmit.Size = new System.Drawing.Size(80, 33);
            this.BtnSubmit.TabIndex = 33;
            this.BtnSubmit.Text = "Submit";
            this.BtnSubmit.UseVisualStyleBackColor = true;
            this.BtnSubmit.Click += new System.EventHandler(this.BtnSubmit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1200, 588);
            this.Controls.Add(this.BtnSubmit);
            this.Controls.Add(this.DtpDateofBirth);
            this.Controls.Add(this.LblDateofBirth);
            this.Controls.Add(this.DtpHireDate);
            this.Controls.Add(this.LblHireDate);
            this.Controls.Add(this.ComboStatus);
            this.Controls.Add(this.LblStatus);
            this.Controls.Add(this.ComboDepartment);
            this.Controls.Add(this.LblDepartment);
            this.Controls.Add(this.TxtSkype);
            this.Controls.Add(this.TxtEmail);
            this.Controls.Add(this.TxtMobilePhone);
            this.Controls.Add(this.TxtHomePhone);
            this.Controls.Add(this.LblSkype);
            this.Controls.Add(this.LblEmail);
            this.Controls.Add(this.LblMobilePhone);
            this.Controls.Add(this.LblHomePhone);
            this.Controls.Add(this.TxtZipCode);
            this.Controls.Add(this.LblZipCode);
            this.Controls.Add(this.ComboState);
            this.Controls.Add(this.LblState);
            this.Controls.Add(this.TxtCity);
            this.Controls.Add(this.LblCity);
            this.Controls.Add(this.TxtTitle);
            this.Controls.Add(this.LblTitle);
            this.Controls.Add(this.ComboPrefix);
            this.Controls.Add(this.TxtlastName);
            this.Controls.Add(this.TxtFirstName);
            this.Controls.Add(this.LblPrefix);
            this.Controls.Add(this.LblLastName);
            this.Controls.Add(this.LblFirstName);
            this.Controls.Add(this.LblFullName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LblFullName;
        private System.Windows.Forms.Label LblFirstName;
        private System.Windows.Forms.Label LblLastName;
        private System.Windows.Forms.Label LblPrefix;
        private System.Windows.Forms.TextBox TxtFirstName;
        private System.Windows.Forms.TextBox TxtlastName;
        private System.Windows.Forms.ComboBox ComboPrefix;
        private System.Windows.Forms.Label LblTitle;
        private System.Windows.Forms.TextBox TxtTitle;
        private System.Windows.Forms.Label LblCity;
        private System.Windows.Forms.TextBox TxtCity;
        private System.Windows.Forms.Label LblState;
        private System.Windows.Forms.ComboBox ComboState;
        private System.Windows.Forms.Label LblZipCode;
        private System.Windows.Forms.TextBox TxtZipCode;
        private System.Windows.Forms.Label LblHomePhone;
        private System.Windows.Forms.Label LblMobilePhone;
        private System.Windows.Forms.Label LblEmail;
        private System.Windows.Forms.Label LblSkype;
        private System.Windows.Forms.TextBox TxtHomePhone;
        private System.Windows.Forms.TextBox TxtMobilePhone;
        private System.Windows.Forms.TextBox TxtEmail;
        private System.Windows.Forms.TextBox TxtSkype;
        private System.Windows.Forms.Label LblDepartment;
        private System.Windows.Forms.ComboBox ComboDepartment;
        private System.Windows.Forms.Label LblStatus;
        private System.Windows.Forms.ComboBox ComboStatus;
        private System.Windows.Forms.Label LblHireDate;
        private System.Windows.Forms.DateTimePicker DtpHireDate;
        private System.Windows.Forms.Label LblDateofBirth;
        private System.Windows.Forms.DateTimePicker DtpDateofBirth;
        private System.Windows.Forms.Button BtnSubmit;
    }
}

